module.exports=[69790,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_view_route_actions_ebfaac4e.js.map