module.exports=[12816,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_upload_page_actions_c5a711b3.js.map