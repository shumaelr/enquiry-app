module.exports=[92013,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_view_page_actions_61c49175.js.map