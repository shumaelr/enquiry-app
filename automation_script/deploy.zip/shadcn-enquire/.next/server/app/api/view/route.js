var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/view/route.js")
R.c("server/chunks/[root-of-the-server]__f6d13e34._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_9ccd6180.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_view_route_actions_ebfaac4e.js")
R.m(8562)
module.exports=R.m(8562).exports
