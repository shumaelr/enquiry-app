var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download/route.js")
R.c("server/chunks/[root-of-the-server]__31893008._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_download_route_actions_1a344694.js")
R.m(53877)
module.exports=R.m(53877).exports
