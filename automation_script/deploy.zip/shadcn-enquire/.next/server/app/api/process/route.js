var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/process/route.js")
R.c("server/chunks/[root-of-the-server]__c1fc85ac._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_process_route_actions_25603b3c.js")
R.m(97749)
module.exports=R.m(97749).exports
