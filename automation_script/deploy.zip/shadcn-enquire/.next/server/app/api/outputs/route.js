var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/outputs/route.js")
R.c("server/chunks/[root-of-the-server]__28e481e1._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_outputs_route_actions_1fb79b8e.js")
R.m(49670)
module.exports=R.m(49670).exports
