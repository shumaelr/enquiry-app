module.exports = [
"[project]/.next-internal/server/app/api/outputs/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_outputs_route_actions_1fb79b8e.js.map