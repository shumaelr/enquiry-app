module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[externals]/fs/promises [external] (fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/app/api/process/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$child_process__$5b$external$5d$__$28$child_process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/child_process [external] (child_process, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs/promises [external] (fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
;
;
// Match the WATCH_DIRECTORY from main.py
const WATCH_DIRECTORY = "/Users/shumaelr/RealCode/Enquiry/2025.11.29R to Shumael - AI - BOQ, Sizing & SLD";
const SCRIPT_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), "..");
async function POST(request) {
    try {
        const formData = await request.formData();
        // Support both single file and multiple files
        let file = formData.get("file");
        let category = formData.get("category");
        // Also check for multiple files format
        const files = formData.getAll("files");
        const categories = formData.getAll("categories");
        // If single file mode
        if (file && category) {
            if (category === "Unknown") {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    error: "Unknown category - cannot process"
                }, {
                    status: 400
                });
            }
            // Save file to the actual WATCH_DIRECTORY that Python uses
            const categoryDir = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(WATCH_DIRECTORY, category);
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["mkdir"])(categoryDir, {
                recursive: true
            });
            const bytes = await file.arrayBuffer();
            const buffer = Buffer.from(bytes);
            const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(categoryDir, file.name);
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["writeFile"])(filePath, buffer);
            // Run processing script with absolute path
            const result = await new Promise((resolve)=>{
                const proc = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$child_process__$5b$external$5d$__$28$child_process$2c$__cjs$29$__["spawn"])("python3", [
                    "process_single.py",
                    filePath
                ], {
                    cwd: SCRIPT_DIR
                });
                let stdout = "";
                let stderr = "";
                proc.stdout.on("data", (data)=>{
                    stdout += data.toString();
                    console.log("stdout:", data.toString());
                });
                proc.stderr.on("data", (data)=>{
                    stderr += data.toString();
                    console.error("stderr:", data.toString());
                });
                proc.on("close", (code)=>{
                    console.log("Process exited with code:", code);
                    if (code === 0) {
                        const match = stdout.match(/Output saved to: (.+)/);
                        resolve({
                            success: true,
                            message: "Processed successfully",
                            outputFile: match ? match[1].trim() : undefined
                        });
                    } else {
                        resolve({
                            success: false,
                            message: stderr || stdout || "Processing failed"
                        });
                    }
                });
                proc.on("error", (err)=>{
                    resolve({
                        success: false,
                        message: `Failed to start process: ${err.message}`
                    });
                });
                // Timeout after 2 minutes
                setTimeout(()=>{
                    proc.kill();
                    resolve({
                        success: false,
                        message: "Processing timed out"
                    });
                }, 120000);
            });
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: result.success,
                filename: file.name,
                category,
                message: result.message,
                outputFile: result.outputFile
            });
        }
        // Multiple files mode
        if (files.length === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: "No files provided"
            }, {
                status: 400
            });
        }
        const results = [];
        for(let i = 0; i < files.length; i++){
            const f = files[i];
            const cat = categories[i] || "Unknown";
            if (cat === "Unknown") {
                results.push({
                    filename: f.name,
                    category: cat,
                    success: false,
                    message: "Unknown category - cannot process"
                });
                continue;
            }
            // Save file to the actual WATCH_DIRECTORY
            const categoryDir = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(WATCH_DIRECTORY, cat);
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["mkdir"])(categoryDir, {
                recursive: true
            });
            const bytes = await f.arrayBuffer();
            const buffer = Buffer.from(bytes);
            const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(categoryDir, f.name);
            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["writeFile"])(filePath, buffer);
            // Run processing script with absolute path
            try {
                const result = await new Promise((resolve)=>{
                    const proc = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$child_process__$5b$external$5d$__$28$child_process$2c$__cjs$29$__["spawn"])("python3", [
                        "process_single.py",
                        filePath
                    ], {
                        cwd: SCRIPT_DIR
                    });
                    let stdout = "";
                    let stderr = "";
                    proc.stdout.on("data", (data)=>{
                        stdout += data.toString();
                    });
                    proc.stderr.on("data", (data)=>{
                        stderr += data.toString();
                    });
                    proc.on("close", (code)=>{
                        if (code === 0) {
                            const match = stdout.match(/Output saved to: (.+)/);
                            resolve({
                                success: true,
                                message: "Processed successfully",
                                outputFile: match ? match[1].trim() : undefined
                            });
                        } else {
                            resolve({
                                success: false,
                                message: stderr || "Processing failed"
                            });
                        }
                    });
                    // Timeout after 2 minutes
                    setTimeout(()=>{
                        proc.kill();
                        resolve({
                            success: false,
                            message: "Processing timed out"
                        });
                    }, 120000);
                });
                results.push({
                    filename: f.name,
                    category: cat,
                    ...result
                });
            } catch (error) {
                results.push({
                    filename: f.name,
                    category: cat,
                    success: false,
                    message: `Error: ${error}`
                });
            }
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            results
        });
    } catch (error) {
        console.error("Error processing files:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: "Failed to process files"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__595a8fa6._.js.map