module.exports = [
"[project]/.next-internal/server/app/upload/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_upload_page_actions_c5a711b3.js.map