module.exports = [
"[project]/.next-internal/server/app/view/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_view_page_actions_61c49175.js.map