var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/process/route.js")
R.c("server/chunks/node_modules_next_e28c32ae._.js")
R.c("server/chunks/[root-of-the-server]__595a8fa6._.js")
R.c("server/chunks/_next-internal_server_app_api_process_route_actions_25603b3c.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/process/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/process/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
