var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download/route.js")
R.c("server/chunks/node_modules_next_f689de71._.js")
R.c("server/chunks/[root-of-the-server]__849c7735._.js")
R.c("server/chunks/_next-internal_server_app_api_download_route_actions_1a344694.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/download/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/download/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
