"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";

export function Header() {
  const pathname = usePathname();

  return (
    <header className="gradient-header text-white shadow-lg">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <span className="text-3xl">📊</span>
            <div>
              <h1 className="text-xl font-bold">Enquiry Document Processor</h1>
              <p className="text-sm text-white/80">AI-Powered PDF Processing</p>
            </div>
          </Link>
          
          <nav className="flex items-center gap-4">
            <Link href="/">
              <Button 
                variant={pathname === "/" ? "secondary" : "ghost"}
                className={pathname === "/" ? "bg-white/20 text-white hover:bg-white/30" : "text-white hover:bg-white/10"}
              >
                📁 Outputs
              </Button>
            </Link>
            <Link href="/upload">
              <Button 
                variant={pathname === "/upload" ? "secondary" : "ghost"}
                className={pathname === "/upload" ? "bg-white/20 text-white hover:bg-white/30" : "text-white hover:bg-white/10"}
              >
                📤 Upload
              </Button>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
