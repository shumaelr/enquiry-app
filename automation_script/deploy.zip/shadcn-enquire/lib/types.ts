export type Category = 'BOQ' | 'Sizing' | 'SLD' | 'Unknown';

export interface ExcelOutput {
  filename: string;
  filepath: string;
  category: Category;
  sourceName: string;
  dateFolder: string;
  time: string;
  createdAt: Date;
}

export interface ProcessingFile {
  id: string;
  name: string;
  relativePath: string;
  category: Category;
  status: 'waiting' | 'uploading' | 'extracting' | 'analyzing' | 'generating' | 'complete' | 'error';
  error?: string;
}

export interface ProcessingResult {
  filename: string;
  category: Category;
  success: boolean;
  message: string;
  outputFile?: string;
}

export const PROCESSING_STEPS = [
  { key: 'uploading', label: 'Uploading', icon: '📤' },
  { key: 'extracting', label: 'Extracting PDF', icon: '📄' },
  { key: 'analyzing', label: 'AI Analysis', icon: '🤖' },
  { key: 'generating', label: 'Generating Excel', icon: '📊' },
  { key: 'complete', label: 'Complete', icon: '✅' },
] as const;
