"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface SheetData {
  headers: string[];
  rows: (string | number | boolean | null)[][];
}

interface FileData {
  filename: string;
  sheets: Record<string, SheetData>;
  sheetNames: string[];
}

function ViewContent() {
  const searchParams = useSearchParams();
  const filePath = searchParams.get("path");
  const [fileData, setFileData] = useState<FileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSheet, setActiveSheet] = useState<string>("");

  useEffect(() => {
    if (!filePath) {
      setError("No file path provided");
      setLoading(false);
      return;
    }

    fetch(`/api/view?path=${encodeURIComponent(filePath)}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load file");
        return res.json();
      })
      .then((data) => {
        setFileData(data);
        if (data.sheetNames && data.sheetNames.length > 0) {
          setActiveSheet(data.sheetNames[0]);
        }
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [filePath]);

  if (loading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="container mx-auto px-6 py-8">
          <Card>
            <CardContent className="py-12 text-center">
              <div className="animate-pulse">
                <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
              </div>
              <p className="text-gray-500 mt-4">Loading file...</p>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  if (error || !fileData) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="container mx-auto px-6 py-8">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-red-500 text-lg">{error || "Failed to load file"}</p>
              <Button className="mt-4 bg-[#3b9daa] hover:bg-[#2d7a87]" asChild>
                <a href="/">Back to Dashboard</a>
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  const currentSheet = fileData.sheets[activeSheet];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-6 py-8">
        {/* File Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-[#2d7a87]">{fileData.filename}</h1>
            <p className="text-gray-500 text-sm mt-1">
              {fileData.sheetNames.length} sheet{fileData.sheetNames.length !== 1 ? "s" : ""}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="border-[#7accc8] text-[#2d7a87]" asChild>
              <a href="/">Back to Dashboard</a>
            </Button>
            <Button 
              className="bg-[#3b9daa] hover:bg-[#2d7a87]"
              onClick={() => window.open(`/api/download?path=${encodeURIComponent(filePath || "")}`, "_blank")}
            >
              Download Excel
            </Button>
          </div>
        </div>

        {/* Sheet Tabs */}
        {fileData.sheetNames.length > 1 && (
          <Tabs value={activeSheet} onValueChange={setActiveSheet} className="mb-6">
            <TabsList>
              {fileData.sheetNames.map((name) => (
                <TabsTrigger key={name} value={name}>
                  {name}
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {fileData.sheets[name]?.rows.length || 0}
                  </Badge>
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        )}

        {/* Data Table */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-[#2d7a87] flex items-center gap-2">
              {activeSheet}
              <Badge variant="secondary">
                {currentSheet?.rows.length || 0} rows
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {currentSheet && currentSheet.headers.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="bg-[#e8f6f7]">
                      {currentSheet.headers.map((header, idx) => (
                        <th
                          key={idx}
                          className="border border-[#c5e5e5] px-4 py-2 text-left font-semibold text-[#2d7a87] whitespace-nowrap"
                        >
                          {header || `Column ${idx + 1}`}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {currentSheet.rows.map((row, rowIdx) => (
                      <tr
                        key={rowIdx}
                        className={rowIdx % 2 === 0 ? "bg-white" : "bg-[#f8fcfc]"}
                      >
                        {currentSheet.headers.map((_, colIdx) => (
                          <td
                            key={colIdx}
                            className="border border-[#e0f0f0] px-4 py-2 text-gray-700"
                          >
                            {row[colIdx] !== null && row[colIdx] !== undefined
                              ? String(row[colIdx])
                              : ""}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No data in this sheet</p>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

export default function ViewPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen">
        <Header />
        <main className="container mx-auto px-6 py-8">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-gray-500">Loading...</p>
            </CardContent>
          </Card>
        </main>
      </div>
    }>
      <ViewContent />
    </Suspense>
  );
}
