"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { ExcelOutput, Category } from "@/lib/types";

const categoryColors: Record<Category, string> = {
  BOQ: "bg-amber-100 text-amber-800 hover:bg-amber-200",
  Sizing: "bg-blue-100 text-blue-800 hover:bg-blue-200",
  SLD: "bg-emerald-100 text-emerald-800 hover:bg-emerald-200",
  Unknown: "bg-gray-100 text-gray-800 hover:bg-gray-200",
};

export default function DashboardPage() {
  const router = useRouter();
  const [outputs, setOutputs] = useState<ExcelOutput[]>([]);
  const [filterCategory, setFilterCategory] = useState<Category | "all">("all");
  const [groupBy, setGroupBy] = useState<"date" | "source" | "category">("date");
  const [loading, setLoading] = useState(true);

  // Fetch outputs from API
  useEffect(() => {
    fetch("/api/outputs")
      .then((res) => res.json())
      .then((data) => {
        if (data.outputs) {
          setOutputs(data.outputs);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch outputs:", err);
        setLoading(false);
      });
  }, []);

  const filteredOutputs = outputs.filter(
    (output) => filterCategory === "all" || output.category === filterCategory
  );

  const groupedOutputs = filteredOutputs.reduce((acc, output) => {
    let key: string;
    if (groupBy === "date") {
      key = output.dateFolder;
    } else if (groupBy === "source") {
      key = output.sourceName;
    } else {
      key = output.category;
    }
    if (!acc[key]) acc[key] = [];
    acc[key].push(output);
    return acc;
  }, {} as Record<string, ExcelOutput[]>);

  const handleViewFile = (output: ExcelOutput) => {
    router.push(`/view?path=${encodeURIComponent(output.filepath)}`);
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-l-4 border-l-[#7accc8]">
            <CardHeader className="pb-2">
              <CardDescription>Total Outputs</CardDescription>
              <CardTitle className="text-3xl text-[#2d7a87]">{outputs.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card className="border-l-4 border-l-amber-400">
            <CardHeader className="pb-2">
              <CardDescription>BOQ Documents</CardDescription>
              <CardTitle className="text-3xl text-amber-600">
                {outputs.filter((o) => o.category === "BOQ").length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card className="border-l-4 border-l-blue-400">
            <CardHeader className="pb-2">
              <CardDescription>Sizing Documents</CardDescription>
              <CardTitle className="text-3xl text-blue-600">
                {outputs.filter((o) => o.category === "Sizing").length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card className="border-l-4 border-l-emerald-400">
            <CardHeader className="pb-2">
              <CardDescription>SLD Documents</CardDescription>
              <CardTitle className="text-3xl text-emerald-600">
                {outputs.filter((o) => o.category === "SLD").length}
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Filters and View Options */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-[#2d7a87]">Filter:</span>
            <div className="flex gap-2">
              {(["all", "BOQ", "Sizing", "SLD"] as const).map((cat) => (
                <Button
                  key={cat}
                  variant={filterCategory === cat ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterCategory(cat)}
                  className={filterCategory === cat ? "bg-[#3b9daa] hover:bg-[#2d7a87]" : ""}
                >
                  {cat === "all" ? "All" : cat}
                </Button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-[#2d7a87]">Group by:</span>
            <Tabs value={groupBy} onValueChange={(v) => setGroupBy(v as typeof groupBy)}>
              <TabsList>
                <TabsTrigger value="date">Date</TabsTrigger>
                <TabsTrigger value="source">Source</TabsTrigger>
                <TabsTrigger value="category">Category</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-gray-500 text-lg">Loading outputs...</p>
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {!loading && outputs.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-gray-500 text-lg">No outputs found</p>
              <p className="text-gray-400 text-sm mt-2">
                Upload some PDFs to get started
              </p>
              <Button className="mt-4 bg-[#3b9daa] hover:bg-[#2d7a87]" asChild>
                <a href="/upload">Upload Documents</a>
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Outputs Grid */}
        {!loading && outputs.length > 0 && (
          <div className="space-y-6">
            {Object.entries(groupedOutputs).map(([group, items]) => (
              <div key={group}>
                <h3 className="text-lg font-semibold text-[#2d7a87] mb-3 flex items-center gap-2">
                  {group}
                  <Badge variant="secondary" className="ml-2">
                    {items.length} file{items.length !== 1 ? "s" : ""}
                  </Badge>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {items.map((output) => (
                    <Card
                      key={output.filepath}
                      className="hover:shadow-lg transition-shadow border-[#e0f0f0] cursor-pointer"
                      onClick={() => handleViewFile(output)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 min-w-0">
                            <CardTitle className="text-sm font-medium truncate text-[#2d7a87]">
                              {output.sourceName}
                            </CardTitle>
                            <CardDescription className="text-xs mt-1">
                              {output.time}
                            </CardDescription>
                          </div>
                          <Badge className={categoryColors[output.category]}>
                            {output.category}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-xs text-gray-500 truncate mb-3">
                          {output.filename}
                        </p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full border-[#7accc8] text-[#2d7a87] hover:bg-[#e8f6f7]"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewFile(output);
                          }}
                        >
                          View Full
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
