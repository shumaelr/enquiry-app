import { NextRequest, NextResponse } from "next/server";
import { readFile } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import * as XLSX from "xlsx";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const filePath = searchParams.get("path");

  if (!filePath) {
    return NextResponse.json({ error: "Missing path parameter" }, { status: 400 });
  }

  // Resolve the file path relative to the outputs directory
  const baseDir = path.resolve(process.cwd(), "..");
  const fullPath = path.join(baseDir, filePath);

  // Security check: ensure path is within outputs directory
  const outputsDir = path.join(baseDir, "outputs");
  if (!fullPath.startsWith(outputsDir)) {
    return NextResponse.json({ error: "Access denied" }, { status: 403 });
  }

  if (!existsSync(fullPath)) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  try {
    const fileBuffer = await readFile(fullPath);
    const workbook = XLSX.read(fileBuffer, { type: "buffer" });
    
    // Get all sheet names and their data
    const sheets: Record<string, { headers: string[]; rows: (string | number | boolean | null)[][] }> = {};
    
    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as (string | number | boolean | null)[][];
      
      if (jsonData.length > 0) {
        const headers = (jsonData[0] || []).map(h => String(h ?? ""));
        const rows = jsonData.slice(1);
        sheets[sheetName] = { headers, rows };
      }
    }

    const filename = path.basename(fullPath);

    return NextResponse.json({
      filename,
      sheets,
      sheetNames: workbook.SheetNames,
    });
  } catch (error) {
    console.error("Error parsing file:", error);
    return NextResponse.json({ error: "Failed to parse file" }, { status: 500 });
  }
}
