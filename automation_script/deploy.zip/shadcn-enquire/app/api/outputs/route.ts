import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

// The Python script saves outputs in the same location as the input PDFs
// WATCH_DIRECTORY from main.py
const WATCH_DIRECTORY = "/Users/shumaelr/RealCode/Enquiry/2025.11.29R to Shumael - AI - BOQ, Sizing & SLD";

export async function GET(request: NextRequest) {
  try {
    const outputs: any[] = [];
    const categories = ["BOQ", "Sizing", "SLD"];

    for (const category of categories) {
      const categoryDir = path.join(WATCH_DIRECTORY, category);
      
      try {
        const files = await fs.readdir(categoryDir);
        
        for (const file of files) {
          // Only look for output files
          if (file.startsWith("Output_") && file.endsWith(".xlsx")) {
            const filePath = path.join(categoryDir, file);
            const fileStat = await fs.stat(filePath);
            
            // Parse filename: Output_SourceName_YYYYMMDD_HHMMSS.xlsx
            const match = file.match(/Output_(.+)_(\d{8})_(\d{6})\.xlsx$/);
            const sourceName = match ? match[1] : file.replace(".xlsx", "").replace("Output_", "");
            const dateStr = match ? match[2] : "";
            const timeStr = match ? match[3] : "";
            const dateFolder = dateStr ? `${dateStr.slice(0,4)}-${dateStr.slice(4,6)}-${dateStr.slice(6,8)}` : "";
            const time = timeStr ? `${timeStr.slice(0,2)}:${timeStr.slice(2,4)}:${timeStr.slice(4,6)}` : "";
            
            outputs.push({
              filename: file,
              filepath: filePath,
              category,
              sourceName,
              dateFolder,
              time,
              createdAt: fileStat.mtime.toISOString(),
            });
          }
        }
      } catch (e) {
        // Category folder may not exist
        console.error(`Error reading ${category} folder:`, e);
        continue;
      }
    }

    // Sort by date descending
    outputs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return NextResponse.json(outputs);
  } catch (error) {
    console.error("Error fetching outputs:", error);
    return NextResponse.json({ error: "Failed to fetch outputs" }, { status: 500 });
  }
}
