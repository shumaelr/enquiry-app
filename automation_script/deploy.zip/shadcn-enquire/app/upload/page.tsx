"use client";

import { useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Category, ProcessingFile } from "@/lib/types";

const categoryColors: Record<Category, string> = {
  BOQ: "bg-amber-100 text-amber-800",
  Sizing: "bg-blue-100 text-blue-800",
  SLD: "bg-emerald-100 text-emerald-800",
  Unknown: "bg-gray-100 text-gray-800",
};

const statusIcons: Record<ProcessingFile["status"], string> = {
  waiting: "⏳",
  uploading: "📤",
  extracting: "📄",
  analyzing: "🤖",
  generating: "📊",
  complete: "✅",
  error: "❌",
};

function detectCategory(path: string): Category {
  const lower = path.toLowerCase();
  const parts = lower.split(/[/\\]/);
  for (const part of parts) {
    if (part === "boq") return "BOQ";
    if (part === "sizing") return "Sizing";
    if (part === "sld") return "SLD";
  }
  return "Unknown";
}

export default function UploadPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"multiple" | "folder">("multiple");
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [files, setFiles] = useState<ProcessingFile[]>([]);
  const [rawFiles, setRawFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showLeaveDialog, setShowLeaveDialog] = useState(false);
  const [overallProgress, setOverallProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState<string>("");
  const [processingMessage, setProcessingMessage] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const handleFilesSelected = useCallback(
    (selectedFiles: FileList | null, isFolder: boolean = false) => {
      if (!selectedFiles) return;

      const pdfFiles = Array.from(selectedFiles).filter((f) =>
        f.name.toLowerCase().endsWith(".pdf")
      );

      setRawFiles(pdfFiles);

      const newFiles: ProcessingFile[] = pdfFiles.map((file, index) => ({
        id: `file-${Date.now()}-${index}`,
        name: file.name,
        relativePath: (file as any).webkitRelativePath || file.name,
        category: isFolder
          ? detectCategory((file as any).webkitRelativePath || file.name)
          : selectedCategory || "Unknown",
        status: "waiting",
      }));

      setFiles(newFiles);
    },
    [selectedCategory]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const items = e.dataTransfer.items;
      if (items) {
        const droppedFiles: File[] = [];
        for (let i = 0; i < items.length; i++) {
          const item = items[i];
          if (item.kind === "file") {
            const file = item.getAsFile();
            if (file && file.name.toLowerCase().endsWith(".pdf")) {
              droppedFiles.push(file);
            }
          }
        }
        if (droppedFiles.length > 0) {
          const dt = new DataTransfer();
          droppedFiles.forEach((f) => dt.items.add(f));
          handleFilesSelected(dt.files, mode === "folder");
        }
      }
    },
    [handleFilesSelected, mode]
  );

  const processFiles = async () => {
    setIsProcessing(true);
    setOverallProgress(0);
    
    const totalFiles = rawFiles.length;
    let completedFiles = 0;
    
    for (let i = 0; i < rawFiles.length; i++) {
      const file = rawFiles[i];
      const fileInfo = files[i];
      
      // Update status to uploading
      setFiles((prev) =>
        prev.map((f, idx) => (idx === i ? { ...f, status: "uploading" } : f))
      );
      setCurrentStep("uploading");
      setProcessingMessage(`Uploading ${file.name}...`);
      
      try {
        // Create FormData
        const formData = new FormData();
        formData.append("file", file);
        formData.append("category", fileInfo.category);
        formData.append("relativePath", fileInfo.relativePath);
        
        // Update to extracting
        setFiles((prev) =>
          prev.map((f, idx) => (idx === i ? { ...f, status: "extracting" } : f))
        );
        setCurrentStep("extracting");
        setProcessingMessage(`Extracting text from ${file.name}...`);
        
        // Call the process API
        const response = await fetch("/api/process", {
          method: "POST",
          body: formData,
        });
        
        // Update to analyzing
        setFiles((prev) =>
          prev.map((f, idx) => (idx === i ? { ...f, status: "analyzing" } : f))
        );
        setCurrentStep("analyzing");
        setProcessingMessage(`AI analyzing ${file.name}...`);
        
        const result = await response.json();
        
        if (result.success) {
          // Update to generating
          setFiles((prev) =>
            prev.map((f, idx) => (idx === i ? { ...f, status: "generating" } : f))
          );
          setCurrentStep("generating");
          setProcessingMessage(`Generating Excel for ${file.name}...`);
          
          await new Promise((resolve) => setTimeout(resolve, 300));
          
          // Mark as complete
          setFiles((prev) =>
            prev.map((f, idx) => (idx === i ? { ...f, status: "complete" } : f))
          );
        } else {
          // Mark as error
          setFiles((prev) =>
            prev.map((f, idx) => (idx === i ? { ...f, status: "error" } : f))
          );
          console.error("Processing failed:", result.error);
        }
      } catch (error) {
        console.error("Error processing file:", error);
        setFiles((prev) =>
          prev.map((f, idx) => (idx === i ? { ...f, status: "error" } : f))
        );
      }
      
      completedFiles++;
      setOverallProgress((completedFiles / totalFiles) * 100);
    }
    
    setCurrentStep("complete");
    setProcessingMessage("All files processed!");
    setIsProcessing(false);
    
    // Redirect to dashboard after completion
    setTimeout(() => router.push("/"), 1500);
  };

  const handleSubmit = async () => {
    if (files.length === 0) return;
    if (mode === "multiple" && !selectedCategory) {
      alert("Please select a category");
      return;
    }
    await processFiles();
  };

  const handleBackClick = (e: React.MouseEvent) => {
    if (isProcessing) {
      e.preventDefault();
      setShowLeaveDialog(true);
    }
  };

  return (
    <div className="min-h-screen">
      <Header />

      <AlertDialog open={showLeaveDialog} onOpenChange={setShowLeaveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Processing in Progress</AlertDialogTitle>
            <AlertDialogDescription>
              Files are still being processed. Are you sure you want to leave? This will not stop the processing but you will lose the progress view.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Stay</AlertDialogCancel>
            <AlertDialogAction onClick={() => router.push("/")}>
              Leave Anyway
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <main className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-[#2d7a87]">Upload Documents</h1>
            <p className="text-gray-500 mt-1">Upload PDF files for AI-powered processing</p>
          </div>
          <Button
            variant="outline"
            className="border-[#7accc8] text-[#2d7a87]"
            onClick={handleBackClick}
            asChild={!isProcessing}
          >
            {isProcessing ? (
              <span>Back to Dashboard</span>
            ) : (
              <a href="/">Back to Dashboard</a>
            )}
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-[#2d7a87]">Select Files</CardTitle>
              <CardDescription>Choose how you want to upload your PDFs</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Mode Selection */}
              <Tabs value={mode} onValueChange={(v) => setMode(v as "multiple" | "folder")}>
                <TabsList className="w-full">
                  <TabsTrigger value="multiple" className="flex-1">Multiple Files</TabsTrigger>
                  <TabsTrigger value="folder" className="flex-1">Folder Upload</TabsTrigger>
                </TabsList>
              </Tabs>

              {/* Category Selection for Multiple Files */}
              {mode === "multiple" && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-[#2d7a87]">Select Category:</label>
                  <div className="flex gap-2">
                    {(["BOQ", "Sizing", "SLD"] as Category[]).map((cat) => (
                      <Button
                        key={cat}
                        variant={selectedCategory === cat ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(cat)}
                        className={selectedCategory === cat ? "bg-[#3b9daa] hover:bg-[#2d7a87]" : ""}
                      >
                        {cat}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {mode === "folder" && (
                <p className="text-sm text-gray-500">
                  Category will be auto-detected from folder structure (BOQ/, Sizing/, SLD/)
                </p>
              )}

              {/* Drop Zone */}
              <div
                className="border-2 border-dashed border-[#7accc8] rounded-lg p-8 text-center cursor-pointer hover:bg-[#e8f6f7] transition-colors"
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => mode === "folder" ? folderInputRef.current?.click() : fileInputRef.current?.click()}
              >
                <div className="text-4xl mb-2">📁</div>
                <p className="text-[#2d7a87] font-medium">
                  {mode === "folder" ? "Drop folder or click to browse" : "Drop files or click to browse"}
                </p>
                <p className="text-gray-400 text-sm mt-1">PDF files only</p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                multiple
                className="hidden"
                onChange={(e) => handleFilesSelected(e.target.files, false)}
              />
              <input
                ref={folderInputRef}
                type="file"
                accept=".pdf"
                multiple
                {...({ webkitdirectory: "true", directory: "true" } as any)}
                className="hidden"
                onChange={(e) => handleFilesSelected(e.target.files, true)}
              />

              {/* File List */}
              {files.length > 0 && !isProcessing && (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {files.map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center justify-between p-2 bg-gray-50 rounded"
                    >
                      <span className="text-sm truncate flex-1">{file.name}</span>
                      <Badge className={categoryColors[file.category]}>{file.category}</Badge>
                    </div>
                  ))}
                </div>
              )}

              {/* Submit Button */}
              {files.length > 0 && !isProcessing && (
                <Button
                  className="w-full bg-[#3b9daa] hover:bg-[#2d7a87]"
                  onClick={handleSubmit}
                  disabled={mode === "multiple" && !selectedCategory}
                >
                  Process {files.length} file{files.length !== 1 ? "s" : ""}
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Processing Status Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-[#2d7a87]">Processing Status</CardTitle>
              <CardDescription>
                {isProcessing ? processingMessage : "Upload files to see processing progress"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {isProcessing && (
                <>
                  <Progress value={overallProgress} className="h-2" />
                  <p className="text-sm text-gray-500 text-center">
                    {Math.round(overallProgress)}% complete
                  </p>
                </>
              )}

              {files.length > 0 && (
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {files.map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center gap-3 p-3 bg-gray-50 rounded"
                    >
                      <span className="text-xl">{statusIcons[file.status]}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{file.name}</p>
                        <p className="text-xs text-gray-500 capitalize">{file.status}</p>
                      </div>
                      <Badge className={categoryColors[file.category]}>{file.category}</Badge>
                    </div>
                  ))}
                </div>
              )}

              {files.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  <div className="text-4xl mb-2">📋</div>
                  <p>No files selected</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
